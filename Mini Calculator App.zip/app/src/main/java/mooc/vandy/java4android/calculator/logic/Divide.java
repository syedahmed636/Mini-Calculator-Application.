package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide {
    // TODO -- start your code here
    public String divide(int num1 , int num2 )
    {   int div , rem;
        try
        {
            div = (int)num1 / num2;
            rem = (int) num1 % num2;
        }
        catch(ArithmeticException e)
        {
            return "Value Two cannot be zero.";
        }

        String result = String.valueOf(div)+" R: "+String.valueOf(rem) ;
        return result;
    }
}
