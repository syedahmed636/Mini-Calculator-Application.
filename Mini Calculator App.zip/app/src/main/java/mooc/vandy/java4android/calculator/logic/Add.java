package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
    // TODO -- start your code here
    public String add(int num1 , int num2 )
    {
        int result = num1 + num2;
        String res = String.valueOf(result) ;
        return res;
    }

}
